﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPlastTopic.com
{
    interface IEngine
    {
        string EngineNumber { get; set; }
        void move();
    }
    interface ITyre
    {
        int MaxSpeed { get; set; }
        void move();
    }
    class ExplicitClass : IEngine, ITyre
    {
        public int maxSpeed;
        public string engineNumber;

        string IEngine.EngineNumber
        {
            get
            {
                return this.engineNumber;
            }
            set
            {
                this.engineNumber = value;
            }
        }
        void IEngine.move()
        {
            Console.WriteLine("I'm move function from IEngine");
        }




        int ITyre.MaxSpeed
        {
            get
            {
                return this.maxSpeed;
            }
            set
            {
                this.maxSpeed = value;
            }
        }

        void ITyre.move()
        {
            Console.WriteLine("I'm move() from ITyre"); ;
        }

        
    }
}

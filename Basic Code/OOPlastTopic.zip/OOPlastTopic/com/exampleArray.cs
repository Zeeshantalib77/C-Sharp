﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPlastTopic.com
{
    class exampleArray
    {
        private int[] myarray = new int[4];

        public void set(int index, int value)
        {
            if (index >= myarray.Length) return;
            
            if(value %2 ==0)
            myarray[index] = value;
        }
        public int get(int index)
        {
            if (index >= myarray.Length) return 0;
            return myarray[index];
        }
    }
}

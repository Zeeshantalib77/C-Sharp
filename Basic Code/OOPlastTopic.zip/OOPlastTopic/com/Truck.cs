﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPlastTopic.com
{
    //interface IEngine
    //{
    //    void move();
    //    string EngineNumber { get; set; }
    //}
    //interface ITyre
    //{
    //    int MaxSpeed { get; set; }
    //    void move();

    //}

    
    //class Truck : IEngine, ITyre
    //{
    //    private int maxSpeed;
    //    private string engineNumber;

    //    public void move()
    //    {
    //        Console.WriteLine("hello I'm move function from Engine");
    //    }

    //    public string EngineNumber
    //    {
    //        get
    //        {
    //            return this.engineNumber;
    //        }
    //        set
    //        {
    //            this.engineNumber = value;
    //        }
    //    }

    //    public int MaxSpeed
    //    {
    //        get
    //        {
    //            return this.maxSpeed;
    //        }
    //        set
    //        {
    //            this.maxSpeed = value;
    //        }
    //    }
    //}
}

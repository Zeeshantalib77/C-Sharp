﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPlastTopic.com
{
    class Student
    {
        private int[] myarray;
        public void setSize(int size) { myarray = new int[size]; }

        public int this[int index]
        {
            get 
            {
                if (index >= myarray.Length) 
                    return 0;
                else
                    return myarray[index];

            }
            set 
            {
                if (index >= myarray.Length)
                    return;

                if (value % 2 == 0)
                    myarray[index] = value;
            }
        }

        public void show()
        {
            foreach (int value in myarray)
            {
                Console.WriteLine(value);
            }
        }
    }
}

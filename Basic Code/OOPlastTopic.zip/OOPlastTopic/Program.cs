﻿using OOPlastTopic.com;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPlastTopic
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Implicit Implimentation

            //Truck truck = new Truck { EngineNumber = "XYZ123", MaxSpeed = 100 };
            
            //IEngine engine = truck;
            //Console.WriteLine(engine.EngineNumber);
            //engine.move();

            //Console.WriteLine();

            //ITyre tyre = truck;
            //Console.WriteLine(tyre.MaxSpeed);
            //tyre.move();
            
            #endregion

            #region Explicit Implimentation

            //ExplicitClass truck = new ExplicitClass { engineNumber = "XYZ123", maxSpeed = 100 };

            //ITyre tyre = truck;
            //tyre.move();

            //Console.WriteLine();

            //IEngine engine = truck;
            //engine.move();


            #endregion

            #region before Indexer

            //exampleArray arrayObj = new exampleArray();

            //arrayObj.set(1, 4);
            //int result = arrayObj.get(1);

            //Console.WriteLine(result);

            //arrayObj.set(2, 24);
            //int result = arrayObj.get(2);
            //Console.WriteLine(result);

            #endregion

            #region Indexer

            Student std = new Student();
            std.setSize(5);

            std[0] = 5;
            std[1] = 10;
            std[2] = 21;
            std[3] = 31;
            std[4] = 40;

            std.show();

            #endregion

            Console.ReadKey(true);
        }
    }
}

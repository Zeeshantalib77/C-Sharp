﻿using AmmazingClass.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AmmazingClass.ViewModels
{
    public class myViewModel : INotifyPropertyChanged
    {
        private Person _person;
        public myViewModel(Person Model)
        {
            this._person = Model;
            this.name = _person.Name;
            this.age = _person.Age;

        }

        private string name;
        public string Name
        {
            get { return this.name; }
            set
            {
                if (value == name)
                    return;

                name = value;
                OnPropertyChange("Name");
            }
        }


        private int age;
        public int Age
        {
            get {return this.age; }
            set
            {
                if (value == age)
                    return;

                age = value;
                OnPropertyChange("Age");
            }

        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChange(string PropertyName)
        {
            var handler = PropertyChanged;
            if(handler != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }
    }
}

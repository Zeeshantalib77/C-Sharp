﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxUnboxOperatorOverloading
{
    class Student
    {
        public int Marks { get; set; }

        public static bool operator > (Student s1, Student s2)
        {
            if (s1.Marks > s2.Marks)
                return true;
            else
                return false;
        }
        public static bool operator <(Student s1, Student s2)
        {
            if (s1.Marks < s2.Marks)
                return true;
            else
                return false;
        }
    }
}

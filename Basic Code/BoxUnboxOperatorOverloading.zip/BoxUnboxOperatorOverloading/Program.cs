﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxUnboxOperatorOverloading
{
    class Program
    {
        static void ExampleStack()
        {
            int j = 5;
            int i = 10;

        }
        static void Main(string[] args)
        {
            #region Boxing and Unboxing

            //int? j;
            //j = 5;

            //int i = (int)j;
            //Console.WriteLine(i);


            //string name = "Ali" + 7;
            #endregion

            #region Operator overloading


            Student std1 = new Student { Marks = 50 };
            Student std2 = new Student { Marks = 60 };

            if(std1 > std2)
            {
                Console.WriteLine("Student 1 is toper");
            }
            else
            {
                Console.WriteLine("Student 2 is toper");
            }

            #endregion
        }
    }
}

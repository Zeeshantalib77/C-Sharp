﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesAndLambda
{
    class Program
    {
        delegate void Mydel();
        delegate int myintDel();
        delegate int myPDel(int p);
        delegate int myTechDel();
        delegate T genericDelegate<T, P>(P num);

        static void Main(string[] args)
        {
            #region Basic Delegates

            ////Mydel del = new Mydel(new Program().display);
            //Mydel del = show;
            //del += new Program().display;
            //del += world;


            //foreach (Mydel mdel in del.GetInvocationList())
            //{
            //    Console.WriteLine(mdel.Method + "method name");
            //    Console.WriteLine(mdel.Target + "target");

            //    mdel.Invoke();
            //    Console.WriteLine();
            //}
            #endregion

            #region Return Delegate type

            //myintDel intDel = myInt;
            //myPDel intDele = myInt3;


            //int result = intDel();
            //int result2 = intDele(12);

            //Console.WriteLine(result);
            //Console.WriteLine(result2);
            
            #endregion

            #region Basic technical terms

            //myTechDel techDel = ReturnFive;
            //techDel += ReturnTen;
            //techDel += ReturnTwelve;

            //int result ;
            //foreach (myTechDel del in techDel.GetInvocationList())
            //{
            //    result = del();
            //    Console.WriteLine(result);

            //}


            #endregion

            #region Advance Technical terms

            //genericDelegate<int, int> genDel = myInt3;
            //Console.WriteLine(genDel(12));



            #endregion

            #region Action and Func 
            //Action MyvoidDel = nothingTodisplaySpecial;
            ////MyvoidDel();


            //Action<int, string> MyActionTwoParameter = diplayValues;
            ////MyActionTwoParameter(20, "Ali");


            //Func<int> myFunc = ReturnFive;
            ////Console.WriteLine(myFunc());

            //Func<int, string> myFunc2 = FuncFriend;
            //string value = myFunc2(12);
            //Console.WriteLine(value);

            #endregion
            Console.ReadKey(true);
        }
        static string FuncFriend(int num) { return num.ToString(); }
        static void diplayValues(int age, string name) { Console.WriteLine("{0}: {1}", age, name); }
        static void nothingTodisplaySpecial() { Console.WriteLine("Special :D"); }
        static int ReturnFive() { return 5; }
        static int ReturnTen() { return 10; }
        static int ReturnTwelve() { return 12; }
        static int myInt() { return 12; }
        static int myInt2() { return 10; }
        static int myInt3(int num) { return num; }

        #region Basic Delegate

        static void show()
        {
            Console.WriteLine("Simple method calling code");
        }

        void display()
        {
            Console.WriteLine("Simple Display calling code");
        }

        static void world() { Console.WriteLine("hello"); }
        #endregion
    }
}

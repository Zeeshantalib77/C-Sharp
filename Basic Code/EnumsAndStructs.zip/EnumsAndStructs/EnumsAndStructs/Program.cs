﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnumsAndStructs
{

    //enum CheckForPlayer
    //{
    //    InsideArea = 1 , OutsideArea = 3
    //}



    struct Book
    {
        private string bookName;

        private int noOfPages;

        private string authorName;


       public Book(string bookName,int noOfPages, string authorName)
        {
            this.bookName = bookName;
            this.noOfPages = noOfPages;
            this.authorName = authorName;
        }


        public void Set(string bookName, int noOfPages, string authorName)
        {
            this.bookName = bookName;
            this.noOfPages = noOfPages;
            this.authorName = authorName;
        }

        public void Show()
        {
            Console.WriteLine("Book Name : {0}",this.bookName);
            Console.WriteLine("Number Of Pages : {0}",this.noOfPages);
            Console.WriteLine("Author Name : {0}", this.authorName);
        }


    }

    class Program
    {
        static void Main(string[] args)
        {
            // CheckForPlayer cp = (CheckForPlayer)3;
            #region Enums
            
            //CheckForPlayer cp = CheckForPlayer.OutsideArea;
            //switch(cp)
            //{
            //    case CheckForPlayer.InsideArea :
            //        Console.WriteLine("Attack!!");
            //        break;
            //    case CheckForPlayer.OutsideArea :
            //        Console.WriteLine("Keep Calm!!");
            //        break;
            //    default :
            //        Console.WriteLine("Wrong Option");
            //        break;
            //}
            #endregion

            #region Structures

            //Book book1 = new Book();
            //book1.Set("Let Us C", 300, "Yashwant");
            //book1.Show();


            //Book book2 = book1;
            //book2.Show();

            //Book book3 = new Book("Let us C",300,"Yashwant");
            //book3.Show();

            // Cannot define default constructor in Structures


            //int number = new int();

            //Console.WriteLine(number);

           

            #endregion


            DateTime currentDateTime = DateTime.Now;

            Console.WriteLine(currentDateTime);

            Console.ReadLine();

        }
    }
}

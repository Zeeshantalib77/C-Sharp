﻿using EventsandLambda.com;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsandLambda
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Event
            //BBCnews bbc = new BBCnews();
            //bbc.informOthers += Show;
            //bbc.informOthers += bbc_informOthers;
            //bbc.informOthers = null;
            ////bbc.informOthers();

            //bbc.News = "News update";
            #endregion
            #region EventHandler
            //BBCnews bbc = new BBCnews() { ID = 10 };
            //BBCnews bbc2 = new BBCnews() { ID = 20 };

            

            //bbc2.Click += bbc2_Click;
            //bbc2.Click += Ali;

            //bbc.News = "Update";
            //bbc2.News = "second Update";
            #endregion
            #region Event Arguments
            
            BBCnews bbcNews = new BBCnews();
            bbcNews.Push += ExtraInfo;
            bbcNews.News = "News";
            #endregion


        }

        private static void ExtraInfo(object sender, student e)
        {
            Console.WriteLine(e.Age);
        }
        static void Ali(object s, EventArgs e)
        {
            Console.WriteLine(((BBCnews)s).ID + " bbc2_Click event");

        }
        static void bbc2_Click(object sender, EventArgs e)
        {
            Console.WriteLine(((BBCnews)sender).ID + " bbc2_Click event");
        }

        static void bbc_Click(object sender, EventArgs e)
        {
            BBCnews myBBC = (BBCnews)sender;

            Console.WriteLine(myBBC.ID + " bbc_click event");
        }

        static void bbc_informOthers()
        {
            Console.WriteLine("Another subscriber");
        }

        static void Show()
        {
            Console.WriteLine("Subscribe");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsandLambda.com
{
    class student : EventArgs
    {
        public int Age { get; set; }
    }
    class BBCnews
    {
        public string News
        {
            get
            {
                return news;
            }
            set
            {
                this.news = value;
                //PublishNews();
                //OnClick();
                OnPush();
            }
        }

       
        private string news;
        public int ID { get; set; }

       public   Action informOthers;
       public event EventHandler Click;
       public event EventHandler<student> Push;
       private void OnPush()
       {
           if (Push != null)
               Push(this, new student { Age = 20 });
       }
       public void OnClick()
       {
           if (Click != null)
               Click(this, new EventArgs());
       }
        public void PublishNews()
        {
            if(informOthers != null)
            informOthers();
        }
    }

    
}

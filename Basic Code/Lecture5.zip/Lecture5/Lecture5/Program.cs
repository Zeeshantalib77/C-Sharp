﻿using System;
namespace Lecture5
{
    class Program
    {
        static void Main(string[] args)
        {

            #region Multi Dimensional Arrays
		 
            // two dimensional array
            //int[,] marks = new int[5, 3]{{32,34,45},{32,45,67},
                                        // {34,65,43},{76,54,23},{43,56,78}};

            //marks[0, 0]  = 45;
            //marks[0, 1] = 42;
            //marks[0, 2] = 43;
            //marks[1, 0] = 44;
            //marks[1, 1] = 41;
            //marks[1, 2] = 44;
            //marks[2, 0] = 43;
            //marks[2, 1] = 42;
            //marks[2, 2] = 41;





            // three dimensional array 

            //int[, ,] marks2 = new int[4, 3, 3];



            //for (int i = 0; i < marks.GetLength(0); i++)
            //{
            //    for (int j = 0; j < marks.GetLength(1); j++)
            //    {

            //        Console.WriteLine("Enter Value : ");
            //        marks[i, j] = int.Parse(Console.ReadLine());
        
            //    }
            //}



            //Console.WriteLine("Values are");

            //for (int i = 0; i < marks.GetLength(0); i++)
                
            //{
            //    for (int j = 0; j < marks.GetLength(1); j++)
            //    {

            //        Console.WriteLine(marks[i,j]);

            //    }
            //}
	#endregion


            #region Jagged Array


            //int[][] marks = new int[4][];

            //marks[0] = new int[2]{43,56};
            //marks[1] = new int[3]{23,45,67};
            //marks[2] = new int[1]{23};
            //marks[3] = new int[2]{23,45};

            //for (int i = 0; i < marks.Length; i++)
            //{
            //    for (int j = 0; j < marks[i].Length; j++)
            //    {
            //        Console.Write(marks[i][j] + " ");
            //    }

            //    Console.WriteLine();
            //}




            #endregion


            #region Random

            //Random rand = new Random();

            //for (int i = 0; i < 10; i++)
            //{
            //    int value = rand.Next(1, 11); // 1 tp 10

            //    Console.WriteLine(value);
            //}

           

            #endregion


            #region Exception Handling

            //try
            //{
            //    int value;

            //    Console.WriteLine("Enter Value : ");

            //    value = int.Parse(Console.ReadLine());

            //    Console.WriteLine("Value you entered is : " + value);
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
                
            //}

            //finally
            //{
            //    Console.WriteLine("Bye");

            //}

            


            #endregion





            Console.ReadLine();



            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lect6.classz
{
     sealed class mySealedClass
    {
        public int  Age { get; set; }
        public string Name { get; set; }
    }

     class Test //: mySealedClass can't derive from sealed type
    {

    }
}

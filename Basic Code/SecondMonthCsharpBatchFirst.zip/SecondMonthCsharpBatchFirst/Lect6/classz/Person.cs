﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lect6.classz
{
    class Person
    {
        public int Age { get; set; }
        public string Name { get; set; }

        public Person(int age, string name)
        {
            this.Age = age;
            this.Name = name;
        }
        public Person()
        {
            Console.WriteLine("Default Constructor");
        }
    }
    class Student : Person 
    {
        public int Marks { get; set; }

        public Student(int marks)
        {
            this.Marks = marks;
        }
        public Student(int marks, int age, string name) : base(age, name)
        {
            this.Marks = marks;
        }

        public Student()
        {
            Console.WriteLine("default constructor of student");
        }
    }
}

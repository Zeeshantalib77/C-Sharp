﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lect6.classz;

namespace Lect6
{
    class Program
    {
        static void Main(string[] args)
        {

            #region 1(a) -Default Constructor inheritance

            //Student std = new Student();
            //std.Marks = 10;
            //Console.WriteLine("Marks of student" + std.Marks);
            #endregion

            #region 1(b) - Inherit Base class's Constructor

            //Student std = new Student(100, 20, "Ali");

            //Console.WriteLine(std.Marks);
            //Console.WriteLine(std.Age);
            //Console.WriteLine(std.Name);

            #endregion

            #region 2 - Static Class


            //myStaticClass.show();


            #endregion

            #region 3 - Sealed Class

            //mySealedClass Sc = new mySealedClass();
            //Sc.Age = 10;
            //Sc.Name = "Ali";

            //Console.WriteLine(Sc.Age);
            //Console.WriteLine(Sc.Name);

            #endregion

            #region 4 - Abstract Class

            //myAbstrctClass tb = new TestingAbstractClass();
            
            #endregion
        }
    }
}

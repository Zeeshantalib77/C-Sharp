﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec2.com.MyProject.MyClassez
{
    class Person
    {
        private int age;
        private string name;


        public void setValues(int Age, string Name)
        {
            if(Age >0 && Age < 60)
            {
                this.age = Age;
            }
            else if(Age <= 0)
            {
                Console.WriteLine("Invalid Age!");
            }
            if (Name == null)
            {
                Console.WriteLine("Invalid Name");
            }
            else
            {
                this.name = Name;
            }
        }





        public void display()
        {
            Console.WriteLine("Age = {0} Name = {1}",
                this.age, this.name);
        }
    }
}

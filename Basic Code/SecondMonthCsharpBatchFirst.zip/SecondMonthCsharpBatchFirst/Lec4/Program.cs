﻿using Lec4.com;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec4
{
    class Program
    {
        static void Main(string[] args)
        {
            Person per = new Person("34603-0677373-1",20, "Ali");
            Console.WriteLine(per.Name);

            Console.ReadKey(true);
        }
    }
    
}

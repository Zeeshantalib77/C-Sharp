﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec4.com
{
    class Person
    {
        public int Age { get; private set; }
        public string Name { get; private set; }
        public string CNIC { get; private set; }

        public Person()
        {
            this.Age = 5;
            this.Name = "NONE";
        }

        public Person(string cnic, int age, string name) : this(age , name)
        {
            this.CNIC = cnic;

        }

        public Person(int age, string name) : this(name)
        {
            this.Age = age;
        }
        public Person(string name)
        {
            this.Name = name;
        }

    }
}

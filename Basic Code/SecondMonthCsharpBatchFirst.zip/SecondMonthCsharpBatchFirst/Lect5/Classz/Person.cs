﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lect5.Classz
{
    class Person
    {
        private int _age;
        private string _name;

        public int Age
        {
            get
            {
                return this._age;
            }
            set
            {
                if (value > 0)
                    this._age = value;
                else
                    Console.WriteLine("Invalid Age");
            }
        }
        public string Name
        {
            get { return this._name; }
            set
            {
                if (value != null)
                    this._name = value;
            }
        }
    }

    class Student
    {
        public Person myPerson { get; set; }
    }
}

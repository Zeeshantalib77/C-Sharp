﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lect5.Classz;

namespace Lect5
{
    
    
    class Program
    {
        static void Main(string[] args)
        {
            #region 1 -Encapsulation

            //Person persone = new Person { Age = 10, Name = "Ali" };
            //Console.WriteLine(persone.Age);
            //Console.WriteLine(persone.Name);

            #endregion
            #region 2 - Composition

            Student std = new Student();

            std.myPerson = new Person();
            std.myPerson.Age = 10;
            std.myPerson.Name = "Ali";

            Console.WriteLine(std.myPerson.Age);


            #endregion
        }
    }
}

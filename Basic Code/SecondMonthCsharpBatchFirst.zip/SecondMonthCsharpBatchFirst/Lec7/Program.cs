﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lec7.com.MyClassez;

namespace Lec7
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Abstract Class
            //Person per = new Person();   // Can't declare an abstract class's object

            // Person per = new student();     // Abstract class can declare an object of its child
            //per.NormalFunc();  

            //per.VirtualFuc();

           // per.AbstractFunc();

            #endregion

            #region Extension Methods

            //int num = 4;
            //int result = num.mySquare();
            //Console.WriteLine(result);


            //string value = "Ali ";
            //string result2 = value.Name();
            //Console.WriteLine(result2);

            #endregion
        }
    }
}

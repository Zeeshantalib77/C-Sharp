﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec7.com.MyClassez
{
    abstract class Person
    {
        public void NormalFunc()
        {
            Console.WriteLine("I'm a normal function of Person");
        }

       virtual public void VirtualFuc()
        {
            Console.WriteLine("I'm a Virtual Function of Person.");
        }

       abstract public void AbstractFunc();

       abstract public void whatsUp();
    }
    class student : Person
    {
       
        public override void VirtualFuc()
        {
            Console.WriteLine("I'm a virtual func()");
        }
      

        public void NormalFunc()
        {
            Console.WriteLine("I'm a normal function of Student");
        }

        public void Display()
        {
            Console.WriteLine("I'm a Display Func of Student");
        }



        public override void AbstractFunc()
        {
            Console.WriteLine("I'm an abstract func");
        }

        public override void whatsUp()
        {
            Console.WriteLine("I'm whats up");
        }
    }
}

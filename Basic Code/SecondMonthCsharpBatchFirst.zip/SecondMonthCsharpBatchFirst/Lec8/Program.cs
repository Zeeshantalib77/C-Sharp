﻿using Lec8.com.myproject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec8
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Simple Interface

            //Person per = new Student();
            //per.Display();
            #endregion

            #region Advance Interface


            //Vehicle vc = new Truck("Green", 110.5f);
            //Console.WriteLine(vc.color);

            //Engine eng = new Truck("XCDER1234");
            //Console.WriteLine(eng.EngineType);

            Truck tr = new Truck();

            Vehicle vc = tr;
            Engine eng = tr;

            Console.WriteLine("Vehicle Interface");
            Console.WriteLine("Color : {0}  MaxSpeed : {1}", vc.color, vc.maxSpeed);
            Console.WriteLine();

            Console.WriteLine("Engine Interface");
            Console.WriteLine("EngineType : {0}", eng.EngineType);


            #endregion

            Console.ReadKey(true);
        }
    }


}

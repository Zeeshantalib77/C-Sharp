﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec8.com.myproject
{

    interface Engine
    {
        string EngineType { get; }
    }
    interface Vehicle
    {
         string color { get; }
         float maxSpeed { get; }
         void display();
    }

    class Truck : Vehicle, Engine
    {
        private string Color;
        private float MaxSpeed;
        private string engineType;
        public Truck(string color, float maxSpeed)
        {
            this.Color = color;
            this.MaxSpeed = maxSpeed;
        }







        public Truck()
        {
            Console.WriteLine("Enter Max Speed: ");
            this.MaxSpeed = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Color");
            this.Color = Console.ReadLine();

            Console.WriteLine("Enter Engine type");
            this.engineType = Console.ReadLine();
        }






        public Truck(string EngineType)
        {
            this.engineType = EngineType; 
        }


        public string color
        {
            get { return this.Color; }
        }

        public float maxSpeed
        {
            get { return this.MaxSpeed; }
        }

        public void display()
        {
            Console.WriteLine("Max Speed :  " + this.maxSpeed);
            Console.WriteLine("Vehicle Color :  " + this.color);
        }

        public string EngineType
        {
            get { return this.engineType; }
        }
    }
}

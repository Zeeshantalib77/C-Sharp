﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec8.com.myproject
{
    interface Person
    {
        void Display();
    }

    class Student : Person
    {
        public void Display()
        {
            Console.WriteLine("Display func()");
        }
    }
}

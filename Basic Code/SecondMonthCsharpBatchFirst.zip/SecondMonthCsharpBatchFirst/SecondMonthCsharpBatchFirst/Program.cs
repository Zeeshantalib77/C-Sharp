﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecondMonthCsharpBatchFirst
{
    struct Person
    {
        public int age;
        public float sallery;

        public student st;
    }

    class student { public int marks;}
    //struct person
    //{
    //    public int age;
    //    public float sallery;
    //    public student st;
    //}

    //struct student
    //{
    //    public int marks;
    //}
    class Program
    {
        static void Main(string[] args)
        {
            //person per = new person();
            //per.age = 10;
            //per.sallery = 100.0f;
            //per.st.marks = 100;

            Person per = new Person();
            per.age = 10;
            per.sallery = 100.0f;

            per.st = new student();
            per.st.marks = 100;


        }
    }
}

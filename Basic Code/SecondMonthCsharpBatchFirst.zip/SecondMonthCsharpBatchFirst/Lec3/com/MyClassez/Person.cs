﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec3.com.MyClassez
{
    class Person
    {
        public int Age { get;  set; }
        //public int Age;
        public void SetAge(int Ag)
        {
            if(Ag > 0)
            this.Age = Ag;
        }
    }
}

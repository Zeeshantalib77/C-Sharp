﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lec7.com.MyClassez
{
    static class ExtensionClass
    {
        public static int mySquare(this int num)
        {
            return num * num;
        }

        public static string Name(this string st)
        {
            return st + " 7COLORS";
        }
    }
}

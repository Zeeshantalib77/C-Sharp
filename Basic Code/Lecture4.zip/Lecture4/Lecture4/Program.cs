﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lecture4
{
    class Program
    {
        static void Main(string[] args)
        {
            #region out,ref
            
            //int num = 9;
            //Func(ref num)
            //int num;
            //Func(out num);
            //Console.WriteLine(num);
            #endregion

            #region object
            
            //object obj = 10;
            //object obj1 = 9.8;
            //object obj3 = "Ali";

            //Console.WriteLine(obj);
            //Console.WriteLine(obj1);
            //Console.WriteLine(obj3);
            #endregion

            #region array, foreach
            //int[] myarray =  { 5,7,3,2,6,8,2,5,1,4,6,7};



            ////myarray[0] = 9;     // *(myarray + 0)
            ////myarray[1] = 10;    // *(myarray + 0)
            ////myarray[2] = 91;    // *(myarray + 0)
            ////myarray[3] = 93;    // *(myarray + 0)
            ////myarray[4] = 69;   // *(myarray + 0)

            ////int num;

            ////for (int i = 0; i < myarray.Length; i++)   
            ////{
            ////    num = myarray[i];
            ////    Console.WriteLine(num); 
            ////}

            //foreach(int number in myarray)
            //{
            //    Console.WriteLine(number);
            //}

            
            #endregion

            #region Implicitly Typed Array

            //var myArray = new []{4,7,3,5,8.3,5,4.8,'8'};

            //foreach (var item in myArray)
            //{
            //    Console.WriteLine(item);
            //}



            #endregion

            #region Passing Array


            //int[] arr = new int[5] {3,4,6,7,1};
            //Show(arr);
            //Change(arr);
            //Show(arr);

            #endregion

            #region params

            Check(5);
            Check(5, 7);
            Check(5, 7,6,3,2,4,5,7,4,3,4,5,3,54);
            Check();

            #endregion



        }

        static void Func(out int num)
        {
            num = 10;
        }


        static void Show(int[] arr)
        {
            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
        }

        static void Change(int[] arr)
        {
            arr[3] = 9;
        }



        static void Check(params int[] arr)
        {
            foreach (int item in arr)
            {
                Console.WriteLine(item);
            }
        }
    }
}
